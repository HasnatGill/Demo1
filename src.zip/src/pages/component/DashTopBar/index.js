import React from 'react'
import TopBar from './TopBar'

function index() {
    return (
        <div>
            <TopBar />
        </div>
    )
}

export default index
