import React from 'react'
import Sidebar from './Sidebar'

function index() {
    return (
        <>
            <Sidebar />
        </>
    )
}

export default index
