import React from 'react'
import Footer from './Footer'

function index() {
    return (
        <div>
            <Footer />
        </div>
    )
}

export default index
