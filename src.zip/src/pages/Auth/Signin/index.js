import React from "react";
import Signin from "./Signin";

function index() {
  return (
    <div>
      <Signin />
    </div>
  );
}

export default index;
