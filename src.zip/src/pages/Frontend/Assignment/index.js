import React from 'react'
import MainPage from './MainPage'

function index() {
  return (
    <div>
      <MainPage/>
    </div>
  )
}

export default index
