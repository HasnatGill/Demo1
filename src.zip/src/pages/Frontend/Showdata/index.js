import React from 'react'
import Show from './Show'

function index() {
    return (
        <div>
            <Show />
        </div>
    )
}

export default index
