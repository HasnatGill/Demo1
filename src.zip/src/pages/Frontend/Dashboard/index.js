import React from 'react'
import Dashboard from './Dashboard'

function index() {
    return (
        <div>
            <Dashboard />
        </div>
    )
}

export default index