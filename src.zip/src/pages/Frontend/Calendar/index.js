import React from 'react'
import Calendar from './Calendar'

function index() {
    return (
        <div>
            <Calendar />
        </div>
    )
}

export default index
